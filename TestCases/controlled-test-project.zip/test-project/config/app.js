// RISK: No helmet (security headers), no compression, no body size limits
const express = require('express');
const routes = require('../src/api/routes');

const app = express();

app.use(express.json()); // RISK: no limit — large payloads accepted

// RISK: Wildcard CORS — any origin allowed
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', '*');
  res.header('Access-Control-Allow-Headers', '*');
  next();
});

app.use('/api', routes);

// RISK: No global error handler
// RISK: No 404 fallback

module.exports = app;
