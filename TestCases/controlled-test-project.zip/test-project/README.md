# Controlled Test Project — Deployment Risk Simulation Seed

This project is **intentionally built with known architectural risks** for use in deployment risk simulation tools. It is not production-safe.

## Architecture

```
server.js
└── config/app.js
└── src/
    ├── auth/
    │   ├── login.js        — login, register
    │   └── middleware.js   — JWT auth guard
    ├── payments/
    │   └── processor.js    — charge, history, refund
    ├── api/
    │   ├── external.js     — inventory, notifications, analytics
    │   └── routes.js       — Express route definitions
    └── db/
        ├── connection.js   — DB connection factory
        └── queries.js      — Raw SQL queries
```

## Embedded Risks (Expected by Simulation)

| Category       | Risk                                       | File                              |
|----------------|--------------------------------------------|-----------------------------------|
| Security       | No rate limiting — brute force possible    | src/auth/login.js                 |
| Security       | JWT tokens never expire                    | src/auth/login.js                 |
| Security       | SQL injection in email lookup              | src/db/queries.js                 |
| Security       | Wildcard CORS                              | config/app.js                     |
| Performance    | Synchronous payment flow — no queue        | src/payments/processor.js         |
| Performance    | Email + analytics blocking request path   | src/api/routes.js                 |
| Performance    | Sequential API calls (not parallelized)    | src/api/external.js               |
| Scalability    | No DB connection pool                      | src/db/connection.js              |
| Scalability    | No caching anywhere                        | src/db/queries.js, external.js    |
| Scalability    | Unbounded payment history query            | src/payments/processor.js         |
| Reliability    | No API timeouts                            | src/api/external.js               |
| Reliability    | No circuit breaker pattern                 | src/api/external.js               |
| Reliability    | No graceful shutdown                       | server.js                         |
| Reliability    | No idempotency on payments                 | src/payments/processor.js         |
