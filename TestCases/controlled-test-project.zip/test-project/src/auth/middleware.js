// RISK: No token blacklist — revoked tokens still work until server restart
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'hardcoded-secret-do-not-use';

function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return res.status(401).json({ error: 'No token provided' });

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

module.exports = { authMiddleware };
