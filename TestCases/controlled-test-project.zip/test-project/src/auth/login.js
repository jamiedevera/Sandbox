// RISK: No rate limiting on login endpoint — brute force vulnerability
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { getUserByEmail, logLoginAttempt } = require('../db/queries');

const JWT_SECRET = process.env.JWT_SECRET || 'hardcoded-secret-do-not-use';

async function login(req, res) {
  const { email, password } = req.body;
  const ip = req.ip;

  // RISK: No check on how many attempts from this IP or email
  // RISK: No CAPTCHA, no lockout, no exponential backoff
  try {
    const user = await getUserByEmail(email);
    if (!user) {
      await logLoginAttempt(email, false, ip);
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const match = await bcrypt.compare(password, user.password_hash);
    await logLoginAttempt(email, match, ip);

    if (!match) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // RISK: Token never expires (no expiresIn)
    const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET);
    res.json({ token, userId: user.id });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
}

async function register(req, res) {
  const { email, password } = req.body;
  try {
    const passwordHash = await bcrypt.hash(password, 10);
    const { createUser } = require('../db/queries');
    const userId = await createUser(email, passwordHash);
    res.status(201).json({ userId });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
}

module.exports = { login, register };
