// RISK: Synchronous payment flow — blocks event loop during processing
// RISK: No queue, no retry logic, no idempotency key
// RISK: Single payment processor — no fallback
const axios = require('axios');
const { getConnection } = require('../db/connection');

const PAYMENT_API_URL = process.env.PAYMENT_API_URL || 'https://api.payments-provider.com';
const PAYMENT_API_KEY = process.env.PAYMENT_API_KEY || 'sk_test_hardcoded';

async function processPayment(userId, amount, currency, cardToken) {
  // RISK: No idempotency check — double charge possible on retry
  // RISK: No timeout configured — waits indefinitely
  const response = await axios.post(`${PAYMENT_API_URL}/charge`, {
    amount,
    currency,
    source: cardToken,
    metadata: { userId }
  }, {
    headers: { Authorization: `Bearer ${PAYMENT_API_KEY}` }
    // NO timeout property
  });

  const charge = response.data;

  // RISK: New DB connection per payment, no transaction
  const conn = getConnection();
  conn.connect();
  await new Promise((resolve, reject) => {
    conn.query(
      'INSERT INTO payments (user_id, amount, currency, charge_id, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
      [userId, amount, currency, charge.id, charge.status],
      (err) => { conn.end(); if (err) reject(err); else resolve(); }
    );
  });

  return charge;
}

async function getPaymentHistory(userId) {
  // RISK: No pagination — fetches ALL records
  // RISK: No caching
  return new Promise((resolve, reject) => {
    const conn = getConnection();
    conn.connect();
    conn.query('SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC',
      [userId], (err, results) => {
        conn.end();
        if (err) reject(err);
        else resolve(results);
      });
  });
}

async function refundPayment(chargeId, amount) {
  // RISK: No check if already refunded — duplicate refund possible
  const response = await axios.post(`${PAYMENT_API_URL}/refund`, {
    charge_id: chargeId,
    amount
  }, {
    headers: { Authorization: `Bearer ${PAYMENT_API_KEY}` }
  });
  return response.data;
}

module.exports = { processPayment, getPaymentHistory, refundPayment };
