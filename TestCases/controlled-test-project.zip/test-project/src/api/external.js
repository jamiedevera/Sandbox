// RISK: No timeout on any external API call
// RISK: No circuit breaker — one slow dependency cascades to full system
// RISK: No retry with backoff
// RISK: No response caching
const axios = require('axios');

const INVENTORY_API = process.env.INVENTORY_API_URL || 'https://inventory.internal/api';
const NOTIFICATION_API = process.env.NOTIFICATION_API_URL || 'https://notify.internal/api';
const ANALYTICS_API = process.env.ANALYTICS_API_URL || 'https://analytics.internal/api';

async function getInventoryForProduct(productId) {
  // RISK: No timeout — hangs indefinitely if inventory service is slow
  const res = await axios.get(`${INVENTORY_API}/products/${productId}/stock`);
  return res.data;
}

async function sendOrderConfirmationEmail(userId, orderId) {
  // RISK: Email sending in request path — slow SMTP = slow response
  const res = await axios.post(`${NOTIFICATION_API}/email`, {
    userId,
    template: 'order_confirmation',
    data: { orderId }
  });
  return res.data;
}

async function trackPurchaseEvent(userId, amount, productId) {
  // RISK: Analytics in hot path — if analytics is down, purchase fails
  const res = await axios.post(`${ANALYTICS_API}/events`, {
    event: 'purchase',
    userId,
    amount,
    productId,
    timestamp: Date.now()
  });
  return res.data;
}

async function fetchProductRecommendations(userId) {
  // RISK: Sequential API calls — could be parallelized with Promise.all
  const history = await axios.get(`${ANALYTICS_API}/users/${userId}/history`);
  const recs = await axios.get(`${ANALYTICS_API}/recommendations?history=${history.data.ids.join(',')}`);
  return recs.data;
}

module.exports = {
  getInventoryForProduct,
  sendOrderConfirmationEmail,
  trackPurchaseEvent,
  fetchProductRecommendations
};
