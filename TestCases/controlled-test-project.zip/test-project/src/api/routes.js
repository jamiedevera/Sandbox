// RISK: No rate limiting middleware on ANY route
// RISK: No request body validation or schema enforcement
const express = require('express');
const router = express.Router();
const { login, register } = require('../auth/login');
const { authMiddleware } = require('../auth/middleware');
const { processPayment, getPaymentHistory } = require('../payments/processor');
const {
  getInventoryForProduct,
  sendOrderConfirmationEmail,
  trackPurchaseEvent
} = require('./external');

// Auth — RISK: unlimited login attempts
router.post('/auth/login', login);
router.post('/auth/register', register);

// Payment — RISK: synchronous, no queue, no idempotency guard
router.post('/payments/charge', authMiddleware, async (req, res) => {
  const { amount, currency, cardToken, productId } = req.body;
  const userId = req.user.userId;

  try {
    // RISK: Sequential awaits — total latency = sum of all dependencies
    const inventory = await getInventoryForProduct(productId);
    if (inventory.stock < 1) {
      return res.status(400).json({ error: 'Out of stock' });
    }

    const charge = await processPayment(userId, amount, currency, cardToken);
    await sendOrderConfirmationEmail(userId, charge.id);   // in request path
    await trackPurchaseEvent(userId, amount, productId);   // in request path

    res.json({ success: true, chargeId: charge.id });
  } catch (err) {
    console.error('Payment route error:', err);
    res.status(500).json({ error: 'Payment failed' });
  }
});

router.get('/payments/history', authMiddleware, async (req, res) => {
  try {
    const history = await getPaymentHistory(req.user.userId);
    res.json(history);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch history' });
  }
});

module.exports = router;
