// RISK: Direct DB calls, no ORM, no query batching, no caching
const { getConnection } = require('./connection');

function getUserByEmail(email) {
  return new Promise((resolve, reject) => {
    const conn = getConnection();
    conn.connect();
    // RISK: SQL injection via string interpolation
    conn.query(`SELECT * FROM users WHERE email = '${email}'`, (err, results) => {
      conn.end();
      if (err) reject(err);
      else resolve(results[0]);
    });
  });
}

function getUserById(id) {
  return new Promise((resolve, reject) => {
    const conn = getConnection();
    conn.connect();
    conn.query('SELECT * FROM users WHERE id = ?', [id], (err, results) => {
      conn.end();
      if (err) reject(err);
      else resolve(results[0]);
    });
  });
}

function createUser(email, passwordHash) {
  return new Promise((resolve, reject) => {
    const conn = getConnection();
    conn.connect();
    conn.query('INSERT INTO users (email, password_hash, created_at) VALUES (?, ?, NOW())',
      [email, passwordHash], (err, results) => {
        conn.end();
        if (err) reject(err);
        else resolve(results.insertId);
      });
  });
}

function logLoginAttempt(email, success, ip) {
  return new Promise((resolve, reject) => {
    const conn = getConnection();
    conn.connect();
    // RISK: Every login attempt writes to DB — no buffering
    conn.query('INSERT INTO login_attempts (email, success, ip, attempted_at) VALUES (?, ?, ?, NOW())',
      [email, success, ip], (err) => {
        conn.end();
        if (err) reject(err);
        else resolve();
      });
  });
}

module.exports = { getUserByEmail, getUserById, createUser, logLoginAttempt };
