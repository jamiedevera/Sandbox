// RISK: No connection pooling — every request opens a new DB connection
const mysql = require('mysql');

function getConnection() {
  return mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || 'password',
    database: process.env.DB_NAME || 'appdb',
  });
}

module.exports = { getConnection };
