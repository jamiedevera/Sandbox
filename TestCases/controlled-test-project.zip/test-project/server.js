const app = require('./config/app');
const PORT = process.env.PORT || 3000;

// RISK: No graceful shutdown — in-flight requests dropped on SIGTERM
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
