const app = require('./config/app');
const { pool } = require('./src/db/connection');

const PORT = process.env.PORT || 3000;

const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// FIX: Graceful shutdown — drain in-flight requests before exiting
function shutdown(signal) {
  console.log(`Received ${signal}. Shutting down gracefully...`);
  server.close(() => {
    console.log('HTTP server closed.');
    pool.end((err) => {
      if (err) console.error('Error closing DB pool:', err);
      else console.log('DB pool closed.');
      process.exit(0);
    });
  });

  // FIX: Force kill after 10s if drain takes too long
  setTimeout(() => {
    console.error('Forcing shutdown after timeout.');
    process.exit(1);
  }, 10000);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
