// FIX: helmet for security headers
// FIX: Explicit CORS origin whitelist
// FIX: Body size limit (100kb)
// FIX: Global error handler
// FIX: 404 handler
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const routes = require('../src/api/routes');

const app = express();

// FIX: Security headers
app.use(helmet());

// FIX: CORS restricted to known origins
const allowedOrigins = (process.env.ALLOWED_ORIGINS || 'https://yourdomain.com').split(',');
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) callback(null, true);
    else callback(new Error('Not allowed by CORS'));
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// FIX: Body size limit — reject payloads over 100kb
app.use(express.json({ limit: '100kb' }));

app.use('/api', routes);

// FIX: 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// FIX: Global error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

module.exports = app;
