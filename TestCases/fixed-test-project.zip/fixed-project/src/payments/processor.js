// FIX: Axios timeout on all payment API calls
// FIX: Idempotency key to prevent double charges
// FIX: DB transaction wrapping charge + record insert
// FIX: Paginated payment history
const axios = require('axios');
const crypto = require('crypto');
const { query } = require('../db/connection');

const PAYMENT_API_URL = process.env.PAYMENT_API_URL;
const PAYMENT_API_KEY = process.env.PAYMENT_API_KEY;
const PAYMENT_TIMEOUT_MS = 10000; // FIX: 10 second timeout

if (!PAYMENT_API_URL || !PAYMENT_API_KEY) {
  throw new Error('PAYMENT_API_URL and PAYMENT_API_KEY env vars are required');
}

const paymentClient = axios.create({
  baseURL: PAYMENT_API_URL,
  timeout: PAYMENT_TIMEOUT_MS, // FIX: global timeout on all payment calls
  headers: { Authorization: `Bearer ${PAYMENT_API_KEY}` }
});

async function processPayment(userId, amount, currency, cardToken, idempotencyKey) {
  // FIX: Require idempotency key — caller must supply or we generate one
  const iKey = idempotencyKey || crypto.randomUUID();

  // FIX: Check if this idempotency key was already processed
  const existing = await query(
    'SELECT * FROM payments WHERE idempotency_key = ?', [iKey]
  );
  if (existing.length > 0) {
    return { alreadyProcessed: true, charge: existing[0] };
  }

  // FIX: Wrapped in DB transaction
  return new Promise((resolve, reject) => {
    query('START TRANSACTION').then(async () => {
      try {
        const response = await paymentClient.post('/charge', {
          amount,
          currency,
          source: cardToken,
          metadata: { userId, idempotencyKey: iKey }
        });

        const charge = response.data;

        await query(
          'INSERT INTO payments (user_id, amount, currency, charge_id, status, idempotency_key, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())',
          [userId, amount, currency, charge.id, charge.status, iKey]
        );

        await query('COMMIT');
        resolve(charge);
      } catch (err) {
        await query('ROLLBACK');
        reject(err);
      }
    }).catch(reject);
  });
}

async function getPaymentHistory(userId, page = 1, pageSize = 20) {
  // FIX: Paginated — never returns unbounded result set
  const offset = (page - 1) * pageSize;
  const results = await query(
    'SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?',
    [userId, pageSize, offset]
  );
  const total = await query('SELECT COUNT(*) as count FROM payments WHERE user_id = ?', [userId]);
  return { payments: results, total: total[0].count, page, pageSize };
}

async function refundPayment(chargeId, amount, userId) {
  // FIX: Check if already refunded before issuing
  const existing = await query(
    'SELECT * FROM payments WHERE charge_id = ? AND status = ?', [chargeId, 'refunded']
  );
  if (existing.length > 0) {
    return { alreadyRefunded: true };
  }

  const response = await paymentClient.post('/refund', { charge_id: chargeId, amount });
  await query('UPDATE payments SET status = ? WHERE charge_id = ?', ['refunded', chargeId]);
  return response.data;
}

module.exports = { processPayment, getPaymentHistory, refundPayment };
