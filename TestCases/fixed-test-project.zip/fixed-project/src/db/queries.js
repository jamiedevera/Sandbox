// FIX: Parameterized queries throughout — no SQL injection
// FIX: Single pool-based query helper — no per-call connection open/close
const { query } = require('./connection');
const NodeCache = require('node-cache');

const userCache = new NodeCache({ stdTTL: 60, checkperiod: 120 }); // FIX: 60s cache

async function getUserByEmail(email) {
  const cacheKey = `user:email:${email}`;
  const cached = userCache.get(cacheKey);
  if (cached) return cached; // FIX: serve from cache

  const results = await query('SELECT * FROM users WHERE email = ?', [email]); // FIX: parameterized
  if (results[0]) userCache.set(cacheKey, results[0]);
  return results[0];
}

async function getUserById(id) {
  const cacheKey = `user:id:${id}`;
  const cached = userCache.get(cacheKey);
  if (cached) return cached;

  const results = await query('SELECT * FROM users WHERE id = ?', [id]);
  if (results[0]) userCache.set(cacheKey, results[0]);
  return results[0];
}

async function createUser(email, passwordHash) {
  const results = await query(
    'INSERT INTO users (email, password_hash, created_at) VALUES (?, ?, NOW())',
    [email, passwordHash]
  );
  return results.insertId;
}

async function logLoginAttempt(email, success, ip) {
  // FIX: Still writes to DB but via pool — non-blocking, pooled
  await query(
    'INSERT INTO login_attempts (email, success, ip, attempted_at) VALUES (?, ?, ?, NOW())',
    [email, success, ip]
  );
}

async function getRecentFailedAttempts(email, ip, windowMinutes = 15) {
  // FIX: Used by rate limiter to enforce brute-force lockout
  const results = await query(
    `SELECT COUNT(*) as count FROM login_attempts
     WHERE (email = ? OR ip = ?) AND success = 0
     AND attempted_at > DATE_SUB(NOW(), INTERVAL ? MINUTE)`,
    [email, ip, windowMinutes]
  );
  return results[0].count;
}

module.exports = { getUserByEmail, getUserById, createUser, logLoginAttempt, getRecentFailedAttempts };
