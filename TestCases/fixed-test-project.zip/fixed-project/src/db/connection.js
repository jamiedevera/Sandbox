// FIX: Connection pool — reuses connections, limits concurrent DB load
const mysql = require('mysql');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASS || 'password',
  database: process.env.DB_NAME || 'appdb',
  connectionLimit: 10,       // FIX: cap concurrent connections
  acquireTimeout: 10000,     // FIX: fail fast if pool exhausted
  waitForConnections: true,
  queueLimit: 50,
});

function query(sql, params) {
  return new Promise((resolve, reject) => {
    pool.query(sql, params, (err, results) => {
      if (err) reject(err);
      else resolve(results);
    });
  });
}

module.exports = { query, pool };
