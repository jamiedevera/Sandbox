// FIX: Timeouts on all external calls
// FIX: Circuit breaker pattern via opossum
// FIX: Response caching with node-cache
// FIX: Parallel API calls where possible
const axios = require('axios');
const CircuitBreaker = require('opossum');
const NodeCache = require('node-cache');

const inventoryCache = new NodeCache({ stdTTL: 30 }); // FIX: 30s cache for inventory

const TIMEOUT_MS = 5000; // FIX: 5s timeout on all external calls

const cbOptions = {
  timeout: TIMEOUT_MS,
  errorThresholdPercentage: 50,  // FIX: open circuit after 50% errors
  resetTimeout: 30000,           // FIX: retry after 30s
};

function makeClient(baseURL) {
  return axios.create({ baseURL, timeout: TIMEOUT_MS });
}

const inventoryClient = makeClient(process.env.INVENTORY_API_URL || 'https://inventory.internal/api');
const notificationClient = makeClient(process.env.NOTIFICATION_API_URL || 'https://notify.internal/api');
const analyticsClient = makeClient(process.env.ANALYTICS_API_URL || 'https://analytics.internal/api');

// FIX: Circuit breakers per downstream service
const inventoryBreaker = new CircuitBreaker(
  (productId) => inventoryClient.get(`/products/${productId}/stock`), cbOptions
);
const analyticsBreaker = new CircuitBreaker(
  (payload) => analyticsClient.post('/events', payload), cbOptions
);

async function getInventoryForProduct(productId) {
  const cacheKey = `inv:${productId}`;
  const cached = inventoryCache.get(cacheKey);
  if (cached) return cached; // FIX: serve from cache

  const res = await inventoryBreaker.fire(productId);
  inventoryCache.set(cacheKey, res.data);
  return res.data;
}

async function sendOrderConfirmationEmail(userId, orderId) {
  // NOTE: Should be moved to a queue — kept here but non-blocking in routes
  try {
    await notificationClient.post('/email', {
      userId,
      template: 'order_confirmation',
      data: { orderId }
    });
  } catch (err) {
    // FIX: Email failure doesn't fail the payment — log and continue
    console.error('Email notification failed (non-fatal):', err.message);
  }
}

async function trackPurchaseEvent(userId, amount, productId) {
  try {
    await analyticsBreaker.fire({ event: 'purchase', userId, amount, productId, timestamp: Date.now() });
  } catch (err) {
    // FIX: Analytics failure is non-fatal — fire and forget with error logging
    console.error('Analytics event failed (non-fatal):', err.message);
  }
}

async function fetchProductRecommendations(userId) {
  // FIX: Parallel calls instead of sequential
  const [history, recsResponse] = await Promise.all([
    analyticsClient.get(`/users/${userId}/history`),
    analyticsClient.get(`/recommendations?userId=${userId}`)
  ]);
  return recsResponse.data;
}

module.exports = {
  getInventoryForProduct,
  sendOrderConfirmationEmail,
  trackPurchaseEvent,
  fetchProductRecommendations
};
