// FIX: Rate limiting on auth and payment routes
// FIX: Request body validation
// FIX: Non-critical side effects (email, analytics) are fire-and-forget
const express = require('express');
const rateLimit = require('express-rate-limit');
const router = express.Router();
const { login, register } = require('../auth/login');
const { authMiddleware } = require('../auth/middleware');
const { processPayment, getPaymentHistory } = require('../payments/processor');
const {
  getInventoryForProduct,
  sendOrderConfirmationEmail,
  trackPurchaseEvent
} = require('./external');

// FIX: Strict rate limit on login — 10 attempts per 15 minutes per IP
const loginRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Too many login attempts, please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// FIX: Payment rate limit — 20 charges per hour per user
const paymentRateLimit = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 20,
  keyGenerator: (req) => req.user?.userId || req.ip,
  message: { error: 'Payment rate limit exceeded.' },
});

router.post('/auth/login', loginRateLimit, login);
router.post('/auth/register', loginRateLimit, register);

router.post('/payments/charge', authMiddleware, paymentRateLimit, async (req, res) => {
  const { amount, currency, cardToken, productId, idempotencyKey } = req.body;
  const userId = req.user.userId;

  // FIX: Input validation
  if (!amount || !currency || !cardToken || !productId) {
    return res.status(400).json({ error: 'amount, currency, cardToken, productId are required' });
  }
  if (typeof amount !== 'number' || amount <= 0) {
    return res.status(400).json({ error: 'amount must be a positive number' });
  }

  try {
    const inventory = await getInventoryForProduct(productId);
    if (inventory.stock < 1) {
      return res.status(400).json({ error: 'Out of stock' });
    }

    const charge = await processPayment(userId, amount, currency, cardToken, idempotencyKey);

    // FIX: Non-critical side effects are fire-and-forget — don't await
    sendOrderConfirmationEmail(userId, charge.id);
    trackPurchaseEvent(userId, amount, productId);

    res.json({ success: true, chargeId: charge.id });
  } catch (err) {
    console.error('Payment route error:', err);
    if (err.response?.status === 402) {
      return res.status(402).json({ error: 'Payment declined' });
    }
    res.status(500).json({ error: 'Payment processing failed' });
  }
});

router.get('/payments/history', authMiddleware, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const pageSize = Math.min(parseInt(req.query.pageSize) || 20, 100); // FIX: cap page size
    const history = await getPaymentHistory(req.user.userId, page, pageSize);
    res.json(history);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch history' });
  }
});

module.exports = router;
