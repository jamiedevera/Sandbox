// FIX: Rate limiting via express-rate-limit + DB-backed attempt tracking
// FIX: JWT tokens expire after 1 hour
// FIX: Brute force lockout after 5 failed attempts per 15 minutes
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { getUserByEmail, logLoginAttempt, getRecentFailedAttempts } = require('../db/queries');

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) throw new Error('JWT_SECRET environment variable is required');

const MAX_ATTEMPTS = 5;
const WINDOW_MINUTES = 15;

async function login(req, res) {
  const { email, password } = req.body;
  const ip = req.ip;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  try {
    // FIX: Check failed attempts before even hitting bcrypt
    const recentFailures = await getRecentFailedAttempts(email, ip, WINDOW_MINUTES);
    if (recentFailures >= MAX_ATTEMPTS) {
      return res.status(429).json({
        error: `Too many failed attempts. Try again in ${WINDOW_MINUTES} minutes.`
      });
    }

    const user = await getUserByEmail(email);
    if (!user) {
      await logLoginAttempt(email, false, ip);
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const match = await bcrypt.compare(password, user.password_hash);
    await logLoginAttempt(email, match, ip);

    if (!match) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // FIX: Token expires in 1 hour
    const token = jwt.sign(
      { userId: user.id, email: user.email },
      JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.json({ token, userId: user.id, expiresIn: 3600 });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
}

async function register(req, res) {
  const { email, password } = req.body;
  if (!email || !password || password.length < 8) {
    return res.status(400).json({ error: 'Valid email and password (min 8 chars) required' });
  }
  try {
    const { createUser } = require('../db/queries');
    const passwordHash = await bcrypt.hash(password, 12); // FIX: cost factor 12
    const userId = await createUser(email, passwordHash);
    res.status(201).json({ userId });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Email already registered' });
    }
    console.error('Register error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
}

module.exports = { login, register };
