// FIX: In-memory token blacklist for logout/revocation
// FIX: Tokens expire (enforced by jwt.verify with expiresIn set at sign time)
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET;
const revokedTokens = new Set(); // In production: use Redis with TTL

function revokeToken(token) {
  revokedTokens.add(token);
}

function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const token = authHeader.split(' ')[1];

  // FIX: Check revocation list before verifying
  if (revokedTokens.has(token)) {
    return res.status(401).json({ error: 'Token has been revoked' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET); // FIX: verifies expiry too
    req.user = decoded;
    req.token = token;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
}

module.exports = { authMiddleware, revokeToken };
