# Fixed Test Project — Deployment Risk Simulation (Hardened)

This is the **fixed version** of the controlled test project. All architectural risks from the original have been resolved.

## Architecture

```
server.js                  — Graceful shutdown (SIGTERM/SIGINT)
└── config/app.js          — helmet, CORS whitelist, body limit, global error handler
└── src/
    ├── auth/
    │   ├── login.js        — Rate limiting, brute force lockout, JWT expiry (1h)
    │   └── middleware.js   — Token blacklist, expiry enforcement
    ├── payments/
    │   └── processor.js    — Idempotency key, DB transaction, timeout, pagination
    ├── api/
    │   ├── external.js     — Timeouts, circuit breakers, caching, parallel calls
    │   └── routes.js       — Rate limits on all routes, input validation, fire-and-forget side effects
    └── db/
        ├── connection.js   — Connection pool (limit: 10)
        └── queries.js      — Parameterized queries, in-memory caching
```

## Risk Resolution Summary

| Category       | Original Risk                              | Fix Applied                                      |
|----------------|--------------------------------------------|--------------------------------------------------|
| Security       | No rate limiting — brute force             | express-rate-limit + DB attempt tracking         |
| Security       | JWT tokens never expire                    | expiresIn: '1h' + expiry enforcement             |
| Security       | SQL injection via string interpolation     | Parameterized queries everywhere                 |
| Security       | Wildcard CORS                              | Explicit origin whitelist via env var            |
| Security       | Hardcoded secrets                          | Env var enforcement with startup assertion       |
| Performance    | Synchronous payment, email+analytics block | Email/analytics fire-and-forget (non-awaited)    |
| Performance    | Sequential API calls                       | Promise.all for parallelizable calls             |
| Scalability    | No DB connection pool                      | mysql pool, limit 10, acquire timeout            |
| Scalability    | No caching                                 | node-cache on user lookups + inventory           |
| Scalability    | Unbounded payment history query            | Paginated with page/pageSize params              |
| Reliability    | No API timeouts                            | axios.create with timeout: 5000ms                |
| Reliability    | No circuit breaker                         | opossum circuit breakers per downstream service  |
| Reliability    | No graceful shutdown                       | SIGTERM/SIGINT handlers drain connections        |
| Reliability    | No idempotency on payments                 | idempotency_key checked before charging          |
| Reliability    | No duplicate refund check                  | Status check before issuing refund               |

## Environment Variables Required

```
JWT_SECRET=<strong-random-secret>
DB_HOST=
DB_USER=
DB_PASS=
DB_NAME=
PAYMENT_API_URL=
PAYMENT_API_KEY=
ALLOWED_ORIGINS=https://yourdomain.com
INVENTORY_API_URL=
NOTIFICATION_API_URL=
ANALYTICS_API_URL=
```
